# -*- coding: utf-8 -*-

TASK_QUEUE_IDENT = "TaskQueue"
TASK_QUEUE_SERVER_IDENT = "TaskQueueServer"
